// App.tsx
import * as React from 'react';

import { StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import MainPage from './pages/MainPage';
import ForgetPasswordPage from './pages/ForgetPasswordPage';
import GroupListPage from './pages/GroupListPage'; 
import GroupDetailsPage from './pages/GroupDetailsPage';
import GroupAssessmentPage from './pages/GroupAssessment';
import GroupAssessmentDetailsPage from './pages/GroupAssessmentDetails';


const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator id={undefined} initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginPage} />
        <Stack.Screen name="Registro" component={RegisterPage} />
        <Stack.Screen name="EsqueciSenha" component={ForgetPasswordPage} />
        <Stack.Screen name="Principal" component={MainPage} />
        <Stack.Screen name="ListaGrupo" component={GroupListPage} />
        <Stack.Screen name="DetalhesGrupo" component={GroupDetailsPage} /> 
        <Stack.Screen name="AvaliacaoGrupo" component={GroupAssessmentPage} /> 
        <Stack.Screen name="DetalhesAvaliacaoGrupo" component={GroupAssessmentDetailsPage} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 40,
    padding: 12,
  },
});
