import React, { useEffect, useState } from 'react';
import { SafeAreaView, StyleSheet, Text, View, Alert, Button } from 'react-native';
import { supabase } from '../lib/supabase'; // Ajuste conforme o caminho do seu arquivo supabase

export default function GroupAssessmentDetailsPage({ route, navigation }) {
  const { avaliacaoId } = route.params; // Obtendo o ID da avaliação da rota
  const [avaliacaoDetalhes, setAvaliacaoDetalhes] = useState<any | null>(null);
  const [loading, setLoading] = useState<boolean>(true); // Controle de loading

  // Função para buscar detalhes da avaliação
  const fetchAvaliacaoDetalhes = async () => {
    setLoading(true); // Inicia o loading
    try {
      const { data, error } = await supabase
        .from('avaliacoes')
        .select('id, nome_avaliador, nota, comentario, data_avaliacao, grupos(nome)') // Incluir nome do grupo
        .eq('id', avaliacaoId)
        .single();

      if (error) {
        throw error;
      }

      setAvaliacaoDetalhes(data);
    } catch (error) {
      Alert.alert('Erro', 'Erro ao carregar os detalhes da avaliação');
    } finally {
      setLoading(false); // Finaliza o loading
    }
  };

  useEffect(() => {
    if (avaliacaoId) {
      fetchAvaliacaoDetalhes();
    }
  }, [avaliacaoId]);

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.loadingText}>Carregando...</Text> {/* Garantir que o texto esteja dentro de um <Text> */}
      </SafeAreaView>
    );
  }

  if (!avaliacaoDetalhes) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.errorText}>Detalhes da avaliação não encontrados.</Text> {/* Garantir que o texto esteja dentro de um <Text> */}
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.detalhesContainer}>
        <Text style={styles.detalhesAvaliador}>Avaliador: {avaliacaoDetalhes.nome_avaliador}</Text> {/* Garantir que o texto esteja dentro de um <Text> */}
        <Text style={styles.detalhesNota}>Nota: {avaliacaoDetalhes.nota}</Text> {/* Garantir que o texto esteja dentro de um <Text> */}
        <Text style={styles.detalhesComentario}>Comentário: {avaliacaoDetalhes.comentario}</Text> {/* Garantir que o texto esteja dentro de um <Text> */}
        <Text style={styles.detalhesData}>Data de Avaliação: {new Date(avaliacaoDetalhes.data_avaliacao).toLocaleString()}</Text> {/* Garantir que o texto esteja dentro de um <Text> */}
        <Text style={styles.detalhesGrupo}>Grupo: {avaliacaoDetalhes.grupos?.nome}</Text> {/* Nome do grupo */}
        <Button title="Voltar para as avaliações" onPress={() => navigation.goBack()} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  loadingText: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 20,
  },
  errorText: {
    fontSize: 18,
    color: 'red',
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 20,
  },
  detalhesContainer: {
    marginBottom: 16,
    padding: 16,
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  detalhesAvaliador: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  detalhesNota: {
    fontSize: 18,
    marginBottom: 8,
  },
  detalhesComentario: {
    fontSize: 18,
    marginBottom: 8,
  },
  detalhesData: {
    fontSize: 18,
    marginBottom: 8,
  },
  detalhesGrupo: {
    fontSize: 18,
    marginBottom: 8,
  },
});
