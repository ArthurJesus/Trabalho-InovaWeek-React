import { Text, SafeAreaView, StyleSheet, TextInput, Image, View, Button, ImageBackground, Alert } from 'react-native';
import React from 'react';
import { supabase } from '../lib/supabase';
import { CustomizableButton } from '../assets/components/buttonCustomizable';

export default function LoginPage({ navigation }) {
  const [email, mudarEmail] = React.useState('');
  const [senha, mudarSenha] = React.useState('');

  const handleLogin = async () => {
    // Validações de campos vazios
    if (!email || !senha) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
      return;
    }
  
    try {
      // Autenticação do usuário
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email,
        password: senha,
      });
  
      if (error) {
        Alert.alert('Erro', error.message); // Exibe um erro caso a autenticação falhe
        return;
      }
  
      // Buscar os dados do usuário na tabela 'usuarios' com a política RLS configurada
      const { data: perfilData, error: perfilError } = await supabase
        .from('usuarios')
        .select('*')
        .eq('user_id', data.user.id)  // Filtra pelo ID do usuário autenticado
        .single();
  
      if (perfilError || !perfilData) {
        Alert.alert('Erro', 'Perfil não encontrado.');
        return;
      }
  
      // Sucesso, navega para a tela principal
      navigation.navigate('Principal', {
        usuarioId: perfilData.user_id,
        usuarioNome: perfilData.nome,
        usuarioEmail: perfilData.email,
      });
      const user = supabase.auth.getUser();
console.log('Usuário autenticado:', user);

    } catch (error) {
      console.error('Erro de autenticação:', error);
      Alert.alert('Erro', 'Algo deu errado. Tente novamente.');
    }
  };
  

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.bgImagemView}>
        <ImageBackground source={require('../assets/images/fundo.jpg')} resizeMode='cover' style={styles.bgImagem}>
          <View style={styles.imagem}>
            <Image source={require('../assets/images/InovaWeek.png')} style={styles.analise} />
          </View>
          <Text style={styles.paragraph}>Bem-Vindo</Text>
          <View style={styles.entradasLogin}>
            <TextInput
              style={styles.input}
              onChangeText={mudarEmail}
              value={email}
              placeholder={"Usuário"}
              keyboardType="email-address"
            />
            <TextInput
              style={styles.input}
              onChangeText={mudarSenha}
              value={senha}
              placeholder={"Senha"}
              secureTextEntry={true}
            />
          </View>
          <View style={styles.botoes}>
            <View>
              <CustomizableButton title="Login" onPress={handleLogin} bgColor={'white'} />
            </View>
            <View>
              <CustomizableButton
                title="Cadastre-se"
                onPress={() => {
                  console.log("Navegando para Registro");
                  navigation.navigate("Registro");
                }}
                bgColor={'white'}
              />
            </View>
            <View>
              <CustomizableButton
                title="Esqueci minha senha"
                onPress={() => {
                  console.log("Navegando para Esqueci minha senha");
                  navigation.navigate("EsqueciSenha");
                }}
                bgColor={'white'}
              />
            </View>
          </View>
        </ImageBackground>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 8
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'white'
  },
  entradasLogin: {
    justifyContent: 'center',
    alignItems: 'center'
  },
  input: {
    backgroundColor: "rgba(222, 222, 222, 0.5)",
    width: 300,
    height: 40,
    padding: 10,
    marginBottom: 8,
    borderColor: "black",
    borderWidth: 1,
    textAlign: 'center',
    color: 'white'
  },
  imagem: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 120
  },
  analise: {
    height: 200,
    width: 200,
    borderRadius: 100,
    marginBottom: 10,
    alignItems: 'center',
    borderWidth: 3
  },
  botoes: {
    flex: 1,
    paddingLeft: 50,
    paddingRight: 50,
    paddingBottom: 75,
    paddingTop: 20,
    justifyContent: 'space-around',
  },
  botao: {
    borderRadius: 10,
    overflow: 'hidden'
  },
  bgImagemView: {
    flex: 1
  },
  bgImagem: {
    flex: 1,
    justifyContent: 'center',
    width: '100%',
    height: '100%'
  }
});
