import { Text, SafeAreaView, StyleSheet, ImageBackground, View, Alert } from 'react-native';
import React from 'react';
import { CustomizableButton } from '../assets/components/buttonCustomizable'; // Botão Customizável
import { supabase } from '../lib/supabase'; // Importar o supabase para logout

export default function MainPage({ navigation }) {

  const handleLogout = async () => {
    // Lógica para limpar sessão antes de navegar para o login
    await supabase.auth.signOut(); // Limpar a sessão
    navigation.navigate('Login'); // Navegar para o login
  };

  const handleFeatureNotImplemented = () => {
    Alert.alert("Em breve", "Esta funcionalidade ainda não foi implementada.");
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.bgImagemView}>
        <ImageBackground 
          source={require('../assets/images/fundo.jpg')} 
          resizeMode="cover" 
          style={styles.bgImagem}
        >
          <View style={styles.buttonsContainer}>
            <CustomizableButton
              title="Verificar Grupos do Inova"
              onPress={() => navigation.navigate('ListaGrupo')}
              bgColor="white"
            />
            <View style={styles.space} />
            <CustomizableButton
              title="Inserir Novo Grupo do Inova"
              onPress={handleFeatureNotImplemented}
              bgColor="white"
            />
            <View style={styles.space} />
            <CustomizableButton
              title="Verificar Avaliações dos Grupos"
              onPress={() => navigation.navigate('AvaliacaoGrupo')}
              bgColor="white"
            />
            <View style={styles.space} />
            <CustomizableButton
              title="Perfil"
              onPress={handleFeatureNotImplemented}
              bgColor="white"
            />
            <View style={styles.space} />
            <CustomizableButton
              title="Logout"
              onPress={handleLogout} // Função de logout
              bgColor="white"
            />
          </View>
        </ImageBackground>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 8
  },
  bgImagemView: {
    flex: 1
  },
  bgImagem: {
    flex: 1,
    justifyContent: 'center',
    width: '100%',
    height: '100%',
  },
  buttonsContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  space: {
    marginVertical: 10,
  }
});
