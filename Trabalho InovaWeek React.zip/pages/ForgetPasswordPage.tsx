import { Text, SafeAreaView, StyleSheet, TextInput, Image, View, Button, ImageBackground, Alert } from 'react-native';
import React from 'react';
import { CustomizableButton } from '../assets/components/buttonCustomizable';

export default function ForgetPasswordPage({ navigation }) {
  const [usuario, mudarUsuario] = React.useState('');
  const [email, mudarEmail] = React.useState('');

  const handlePasswordReset = () => {
    if (!usuario || !email) {
      Alert.alert('Erro', 'Preencha todos os campos.');
      return;
    }
    // Aqui você pode adicionar a lógica de recuperação de senha (ex: chamar uma API)
    console.log("Nova senha solicitada com sucesso!");
    navigation.navigate("Login");
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.bgImagemView}>
        <ImageBackground source={require('../assets/images/fundo.jpg')} resizeMode='cover' style={styles.bgImagem}>
          <View style={styles.imagem}>
            <Image source={require('../assets/images/InovaWeek.png')} style={styles.analise} />
          </View>
          <Text style={styles.paragraph}>
            Esqueci Minha Senha
          </Text>
          <View style={styles.entradasLogin}>
            <TextInput
              style={styles.input}
              onChangeText={mudarUsuario}
              value={usuario}
              placeholder={"Usuário"}
            />
            <TextInput
              style={styles.input}
              onChangeText={mudarEmail}
              value={email}
              placeholder={"E-mail"}
            />
          </View>
          <View style={styles.botaoLogin}>
            <View>
              <CustomizableButton
                title="Solicitar Nova Senha"
                onPress={handlePasswordReset} 
                bgColor={'white'} 
              />
            </View>
          </View>
        </ImageBackground>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 8
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'white'
  },
  entradasLogin: {
    justifyContent: 'center',
    alignItems: 'center'
  },
  input: {
    backgroundColor: "rgba(222, 222, 222, 0.5)",
    width: 300,
    height: 40,
    padding: 10,
    marginBottom: 8,
    borderColor: "black",
    borderWidth: 1,
    textAlign: 'center',
    color: 'white'
  },
  imagem: {
    alignItems: 'center',
    justifyContent: 'center'
  },
  analise: {
    height: 200,
    width: 200,
    borderRadius: 850,
    marginBottom: 10,
    alignItems: 'center',
    borderWidth: 3
  },
  botaoLogin: {
    width: '100%',
    marginTop: 10,
    justifyContent: 'center',
    alignItems: 'center'
  },
  botao: {
    width: '50%'
  },
  bgImagemView: {
    flex: 1
  },
  bgImagem: {
    flex: 1,
    justifyContent: 'center',
    width: '100%',
    height: '100%'
  }
});
