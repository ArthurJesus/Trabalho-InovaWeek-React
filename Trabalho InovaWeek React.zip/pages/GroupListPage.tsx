import React, { useEffect, useState } from 'react';
import { SafeAreaView, StyleSheet, Text, View, TouchableOpacity, FlatList, Alert } from 'react-native';
import { supabase } from '../lib/supabase'; // Ajuste conforme o caminho do seu arquivo supabase

export default function GroupListPage({ navigation }) {
  const [grupos, setGrupos] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true); // Controle de loading

  // Função para buscar os grupos do banco de dados
  const fetchGrupos = async () => {
    console.log("Iniciando fetchGrupos");
    setLoading(true); // Inicia o loading

    try {
      const { data, error } = await supabase.from('grupos').select('id, nome, tema');
      if (error) {
        console.error("Erro ao buscar grupos:", error);
        throw error;
      }

      console.log("Grupos recebidos:", data); // Log dos grupos recebidos
      setGrupos(data || []); // Atualiza o estado, garantindo fallback
    } catch (error) {
      Alert.alert('Erro', 'Erro ao carregar os grupos');
    } finally {
      console.log("Finalizando fetchGrupos");
      setLoading(false); // Finaliza o loading
    }
  };

  // UseEffect para carregar os dados apenas uma vez
  useEffect(() => {
    console.log("Chamando useEffect para buscar grupos");
    fetchGrupos();
  }, []); // Array vazio garante que só é executado uma vez

  const renderItem = ({ item }) => {
    console.log("Renderizando item:", item);
    return (
      <View style={styles.grupoContainer}>
        <Text style={styles.grupoNome}>{item.nome}</Text>
        <Text style={styles.grupoTema}>{item.tema}</Text>
        <TouchableOpacity
          style={styles.botao}
          onPress={() => navigation.navigate('DetalhesGrupo', { groupId: item.id })}
        >
          <Text style={styles.botaoText}>Mais Informações</Text>
        </TouchableOpacity>
      </View>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.loadingText}>Carregando grupos...</Text>
      </SafeAreaView>
    );
  }

  if (!loading && grupos.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.errorText}>Nenhum grupo encontrado.</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={grupos}
        keyExtractor={(item) => item.id.toString()} // Garante que o id é uma string
        renderItem={renderItem}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  loadingText: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 20,
  },
  errorText: {
    fontSize: 18,
    color: 'red',
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 20,
  },
  grupoContainer: {
    padding: 16,
    marginBottom: 16,
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  grupoNome: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  grupoTema: {
    fontSize: 16,
    color: '#555',
    marginVertical: 8,
  },
  botao: {
    padding: 10,
    backgroundColor: '#007bff',
    borderRadius: 8,
    alignItems: 'center',
  },
  botaoText: {
    color: 'white',
    fontWeight: 'bold',
  },
});
