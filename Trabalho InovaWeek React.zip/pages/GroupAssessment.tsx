import { useEffect, useState } from 'react';
import { Text, View, FlatList, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import { supabase } from '../lib/supabase';
import React from 'react';

export default function AvaliacaoGrupo({ navigation }) {
  const [avaliacoes, setAvaliacoes] = useState([]);
  const [loading, setLoading] = useState(true);

  // Função para buscar todas as avaliações e o nome do grupo
  useEffect(() => {
    const fetchAvaliacoes = async () => {
      try {
        setLoading(true);

        // Realiza a junção entre as tabelas 'avaliacoes' e 'grupos' para pegar o nome do grupo
        const { data, error } = await supabase
            .from('avaliacoes')
            .select('id, nome_avaliador, nota, comentario, data_avaliacao, grupos(nome)'); // Fazendo a junção através de um relacionamento no Supabase

        if (error) throw error;

        if (data.length === 0) {
          Alert.alert('Aviso', 'Nenhuma avaliação encontrada.');
        }

        setAvaliacoes(data);
      } catch (error) {
        console.error('Erro ao carregar avaliações:', error);
        Alert.alert('Erro', 'Erro ao carregar as avaliações');
      } finally {
        setLoading(false);
      }
    };

    fetchAvaliacoes();
  }, []);

  // Exibe os detalhes da avaliação ao clicar
  const handleDetailPress = (avaliacaoId) => {
    navigation.navigate('DetalhesAvaliacaoGrupo', { avaliacaoId }); // Passando apenas o ID da avaliação
  };

  if (loading) {
    return <ActivityIndicator size="large" color="#0000ff" />;
  }

  return (
    <View>
      {avaliacoes.length > 0 ? (
        <FlatList
          data={avaliacoes}
          keyExtractor={(item) => item.id.toString()} // Garantir que o keyExtractor seja um string
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => handleDetailPress(item.id)}> {/* Passando o id */}
              <View style={{ padding: 10, borderBottomWidth: 1, borderBottomColor: '#ccc' }}>
                <Text style={{ fontWeight: 'bold' }}>{item.nome_avaliador}</Text>
                <Text>Grupo: {item.grupos?.nome}</Text> {/* Exibindo o nome do grupo */}
              </View>
            </TouchableOpacity>
          )}
        />
      ) : (
        <Text>Nenhuma avaliação encontrada</Text>
      )}
    </View>
  );
}
