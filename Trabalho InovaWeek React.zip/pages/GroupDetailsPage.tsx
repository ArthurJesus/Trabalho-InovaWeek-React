// GroupDetailsPage.tsx
import React, { useEffect, useState } from 'react';
import { SafeAreaView, StyleSheet, Text, View, Alert, Button } from 'react-native';
import { supabase } from '../lib/supabase'; // Ajuste conforme o caminho do seu arquivo supabase

export default function GroupDetailsPage({ route, navigation }) {
  const { groupId } = route.params; // Obtendo o ID do grupo da rota
  const [grupoDetalhes, setGrupoDetalhes] = useState<any | null>(null);
  const [loading, setLoading] = useState<boolean>(true); // Controle de loading

  // Função para buscar detalhes do grupo selecionado
  const fetchGroupDetails = async () => {
    setLoading(true); // Inicia o loading
    try {
      const { data, error } = await supabase
        .from('grupos')
        .select('*')
        .eq('id', groupId)
        .single();
      if (error) {
        throw error;
      }
      setGrupoDetalhes(data);
    } catch (error) {
      Alert.alert('Erro', 'Erro ao carregar os detalhes do grupo');
    } finally {
      setLoading(false); // Finaliza o loading
    }
  };

  useEffect(() => {
    fetchGroupDetails();
  }, [groupId]);

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.loadingText}>Carregando...</Text>
      </SafeAreaView>
    );
  }

  if (!grupoDetalhes) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.errorText}>Detalhes do grupo não encontrados.</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.detalhesContainer}>
        <Text style={styles.detalhesNome}>Nome: {grupoDetalhes.nome}</Text>
        <Text style={styles.detalhesTema}>Tema: {grupoDetalhes.tema}</Text>
        <Text style={styles.detalhesData}>Data de Apresentação: {grupoDetalhes.data_apresentacao}</Text>
        <Text style={styles.detalhesAlunos}>Alunos Participantes: {grupoDetalhes.alunos_participantes.join(', ')}</Text>
        <Button title="Voltar para a lista de grupos" onPress={() => navigation.goBack()} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  loadingText: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 20,
  },
  errorText: {
    fontSize: 18,
    color: 'red',
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 20,
  },
  detalhesContainer: {
    marginBottom: 16,
    padding: 16,
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  detalhesNome: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  detalhesTema: {
    fontSize: 18,
    marginBottom: 8,
  },
  detalhesData: {
    fontSize: 18,
    marginBottom: 8,
  },
  detalhesAlunos: {
    fontSize: 18,
    color: '#555',
  },
});
