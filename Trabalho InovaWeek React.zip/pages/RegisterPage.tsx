import { Text, SafeAreaView, StyleSheet, TextInput, Image, View, Alert, ImageBackground } from 'react-native';
import React from 'react';
import { CustomizableButton } from '../assets/components/buttonCustomizable';
import { supabase } from '../lib/supabase';

export default function RegisterPage({ navigation }) {
  const [usuario, mudarUsuario] = React.useState('');
  const [email, mudarEmail] = React.useState('');
  const [senha, mudarSenha] = React.useState('');
  const [confirmarSenha, mudarConfirmarSenha] = React.useState('');

  const handleRegister = async () => {
    // Verificação de campos vazios
    if (!usuario || !email || !senha || !confirmarSenha) {
      Alert.alert("Erro", "Por favor, preencha todos os campos.");
      return;
    }
  
    // Verificar se as senhas coincidem
    if (senha !== confirmarSenha) {
      Alert.alert("Erro", "As senhas não coincidem");
      return;
    }
  
    // Verificar se a senha tem pelo menos 6 caracteres
    if (senha.length < 6) {
      Alert.alert("Erro", "A senha precisa ter pelo menos 6 caracteres.");
      return;
    }
  
    try {
      // Criar o usuário no Supabase Auth
      const { data: userData, error: authError } = await supabase.auth.signUp({
        email: email,
        password: senha,
      });
  
      if (authError) {
        console.error('Erro de autenticação:', authError);
        Alert.alert("Erro", `Erro ao criar conta: ${authError.message}`);
        return;
      }
  
      if (userData && userData.user) {
        // Verificar se o usuário foi criado com sucesso no auth
        const { user } = userData;
        console.log('Usuário criado com sucesso:', user);
  
        // Inserir os dados do e-mail, senha e nome na tabela 'usuarios'
        const { error: insertUserError } = await supabase
          .from('usuarios')
          .insert([
            {
              email: email,
              senha: senha,  // Inserir a senha corretamente na tabela
              nome: usuario, // Nome do usuário
              user_id: user.id, // Relacionar com o id do Supabase Auth
            },
          ]);
  
        if (insertUserError) {
          console.error('Erro ao salvar dados do usuário:', insertUserError);
          Alert.alert("Erro", "Erro ao salvar os dados do usuário. Tente novamente.");
          return;
        }
  
        Alert.alert(
          "Sucesso",
          "Cadastro realizado com sucesso! Verifique seu e-mail para confirmar a conta."
        );
        navigation.navigate("Login");
      } else {
        Alert.alert("Erro", "Ocorreu um erro ao criar a conta. Tente novamente.");
      }
    } catch (error) {
      console.error('Erro ao cadastrar:', error);
      Alert.alert('Erro', 'Houve um erro ao registrar sua conta. Tente novamente.');
    }
  };
  

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.bgImagemView}>
        <ImageBackground source={require('../assets/images/fundo.jpg')} resizeMode="cover" style={styles.bgImagem}>
          <View style={styles.imagem}>
            <Image source={require('../assets/images/InovaWeek.png')} style={styles.analise} />
          </View>
          <Text style={styles.paragraph}>Cadastre-se</Text>
          <View style={styles.entradasLogin}>
            <TextInput
              style={styles.input}
              onChangeText={mudarUsuario}
              value={usuario}
              placeholder="Usuário"
              placeholderTextColor="#ddd"
            />
            <TextInput
              style={styles.input}
              onChangeText={mudarEmail}
              value={email}
              placeholder="E-mail"
              keyboardType="email-address"
              autoCapitalize="none"
              placeholderTextColor="#ddd"
            />
            <TextInput
              style={styles.input}
              onChangeText={mudarSenha}
              value={senha}
              placeholder="Senha"
              secureTextEntry
              placeholderTextColor="#ddd"
            />
            <TextInput
              style={styles.input}
              onChangeText={mudarConfirmarSenha}
              value={confirmarSenha}
              placeholder="Confirme sua senha"
              secureTextEntry
              placeholderTextColor="#ddd"
            />
          </View>
          <View style={styles.botaoLogin}>
            <CustomizableButton title="Cadastrar" onPress={handleRegister} bgColor="white" />
          </View>
        </ImageBackground>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
    color: "white",
  },
  entradasLogin: {
    justifyContent: "center",
    alignItems: "center",
  },
  input: {
    backgroundColor: "rgba(222, 222, 222, 0.5)",
    width: 300,
    height: 40,
    padding: 10,
    marginBottom: 8,
    borderColor: "black",
    borderWidth: 1,
    textAlign: "center",
    color: "white",
  },
  imagem: {
    alignItems: "center",
    justifyContent: "center",
  },
  analise: {
    height: 200,
    width: 200,
    borderRadius: 850,
    marginBottom: 10,
    alignItems: "center",
    borderWidth: 3,
  },
  botaoLogin: {
    width: "100%",
    marginTop: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  bgImagemView: {
    flex: 1,
  },
  bgImagem: {
    flex: 1,
    justifyContent: "center",
    width: "100%",
    height: "100%",
  },
});
