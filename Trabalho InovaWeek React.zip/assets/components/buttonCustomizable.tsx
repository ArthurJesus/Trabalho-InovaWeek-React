import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';

type CustomizableButtonProps = {
  onPress: () => void;
  title: string;
  bgColor: string;
  disabled?: boolean;  // Adicionando a propriedade disabled
};

export const CustomizableButton: React.FC<CustomizableButtonProps> = ({
  onPress,
  title,
  bgColor,
  disabled = false,  // Definindo 'disabled' como opcional com valor padrão 'false'
}) => {
  return (
    <TouchableOpacity
      style={[
        styles.button,
        { backgroundColor: bgColor, opacity: disabled ? 0.6 : 1 }, // Alterando opacidade se o botão estiver desabilitado
      ]}
      onPress={disabled ? undefined : onPress}  // Desabilita a ação onPress se o botão estiver desabilitado
      disabled={disabled}  // Passando o 'disabled' para o TouchableOpacity
    >
      <Text style={styles.text}>{title}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    borderRadius: 10,
    overflow: 'hidden',
    padding: 10,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 5, // Sombra no Android
    shadowColor: '#000', // Sombra no iOS
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.5,
  },
  text: {
    textAlign: 'center',
    color: 'black',  // Garantindo que o texto permaneça visível mesmo quando o botão estiver desabilitado
  },
});
