import AsyncStorage from '@react-native-async-storage/async-storage'
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://gqqingcxtvoyzxfszyhv.supabase.co'
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdxcWluZ2N4dHZveXp4ZnN6eWh2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzE4OTEzMjcsImV4cCI6MjA0NzQ2NzMyN30._SrjS-5hsQ7ceuHw7NcbCtNR7uwWQ8tr4LAEjKGcEwg"

export const supabase = createClient(supabaseUrl, supabaseAnonKey as string, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
})